clc; close all;
sim('Gain_Adjustment');
time = err(:, 1);

% Error
h = figure(2);
plot(time, err(:, 2), 'LineWidth', 1.5);
grid on
xlabel('time')
ylabel('error = y - y_m')
title('Error Between the Required Model Output and the Actual Output')
print(h,'-dpng','-r1000','Error')

% Output
h = figure(3);
hold all
plot(time, output(:, 2), 'LineWidth', 1.5);
plot(time, output(:, 3), 'LineWidth', 1.5);
plot(time, output(:, 4), 'LineWidth', 1.5);
plot(time, output(:, 5), 'LineWidth', 1.5);
grid on
xlabel('time')
ylabel('Simulation Output')
title('Simulation Output Vs Time')
legend('G_m Model Output', 'Adjusted Output', 'Otiginal System Output', 'Input (Required Output)')
print(h,'-dpng','-r1000','Output')

% Control Parameters
h = figure(4);
hold all
plot(time, ContParam(:, 2), 'LineWidth', 1.5);
grid on
xlabel('time')
ylabel('\theta')
title('\theta Vs Time')
legend('\theta')
ylim([0 ContParam(end, 2)+0.5]);
print(h,'-dpng','-r1000','Theta')
