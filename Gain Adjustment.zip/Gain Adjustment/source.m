clc; close all; clear all;
global a;
global b;
global gamma;
global theta;


a = 2;
b = 4;
gamma = 1;
theta = 2;